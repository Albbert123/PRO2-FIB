var searchData=
[
  ['finalizar_5ftorneo_135',['finalizar_torneo',['../class_cjt___torneos.html#a73ecf59cf7d74f24e202ebbc9c071b64',1,'Cjt_Torneos::finalizar_torneo()'],['../class_torneo.html#af3762f9e6116804ff3c87feaaa2999d2',1,'Torneo::finalizar_torneo()']]]
];
