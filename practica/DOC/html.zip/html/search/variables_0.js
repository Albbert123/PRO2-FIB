var searchData=
[
  ['categoria_165',['categoria',['../class_torneo.html#ad9bec7ef311a416138abb99f3a487b3e',1,'Torneo']]],
  ['categorias_166',['categorias',['../class_cjt___categorias.html#adf80e57f96d5196686fa3f9484b3a374',1,'Cjt_Categorias']]],
  ['circuito_167',['circuito',['../class_cjt___torneos.html#a586aaa63faa516de86e12be674e77dd5',1,'Cjt_Torneos']]]
];
