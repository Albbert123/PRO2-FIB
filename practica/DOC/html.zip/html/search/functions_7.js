var searchData=
[
  ['leer_138',['leer',['../class_cjt___categorias.html#a3733b9656ad284566a11991e0da61c67',1,'Cjt_Categorias::leer()'],['../class_cjt___jugadores.html#a753d3bc139ca9107cfc94d464653d473',1,'Cjt_Jugadores::leer()'],['../class_cjt___torneos.html#a701c9791882fede2633ac81fa3968a41',1,'Cjt_Torneos::leer()']]],
  ['leer_5finscritos_139',['leer_inscritos',['../class_torneo.html#ab37b681b9848112b1261059e8de08893',1,'Torneo']]],
  ['leer_5fresultados_140',['leer_resultados',['../class_torneo.html#abfbaabd36baaa0a7f22e075d1cbdb0d7',1,'Torneo']]],
  ['listar_5fcategorias_141',['listar_categorias',['../class_cjt___categorias.html#a9ee590c5bd7e0fa5b4eb0514bd1c0272',1,'Cjt_Categorias']]],
  ['listar_5fjugadores_142',['listar_jugadores',['../class_cjt___jugadores.html#a1a96c570a483da224c882216d3080dd0',1,'Cjt_Jugadores']]],
  ['listar_5franking_143',['listar_ranking',['../class_cjt___jugadores.html#a4c60a851b0212b02d07f2048d13188d6',1,'Cjt_Jugadores']]],
  ['listar_5ftorneos_144',['listar_torneos',['../class_cjt___torneos.html#aff7c5e40a72e709fe73ff24253ec033c',1,'Cjt_Torneos']]]
];
