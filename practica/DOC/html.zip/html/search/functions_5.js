var searchData=
[
  ['iniciar_5ftorneo_136',['iniciar_torneo',['../class_cjt___torneos.html#ae4d19a5b2730ed5ae86e2b0cdd134e98',1,'Cjt_Torneos::iniciar_torneo()'],['../class_torneo.html#a577aa6ee32e24b21346bc8c052b3cdb2',1,'Torneo::iniciar_torneo()']]]
];
