var searchData=
[
  ['torneo_89',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#aac74f4f1cb5c3f1ab05a9c9ade4b2e8b',1,'Torneo::Torneo(int categoria)']]],
  ['torneo_2ecc_90',['Torneo.cc',['../_torneo_8cc.html',1,'']]],
  ['torneo_2ehh_91',['Torneo.hh',['../_torneo_8hh.html',1,'']]],
  ['torneos_5fjugados_92',['torneos_jugados',['../class_jugador.html#a0748546e4b663237c90cf07e10326977',1,'Jugador::torneos_jugados()'],['../struct_torneo_1_1_actualizar__datos.html#a4a874bd17619fd612fb8cb9efc614f59',1,'Torneo::Actualizar_datos::torneos_jugados()']]]
];
