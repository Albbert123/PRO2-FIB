var searchData=
[
  ['juegos_5fg_39',['juegos_g',['../class_jugador.html#a12d726742e3690a515ae3def2c73b278',1,'Jugador::juegos_g()'],['../struct_torneo_1_1_actualizar__datos.html#a815ee965a3481284e3c0e858345fb030',1,'Torneo::Actualizar_datos::juegos_g()']]],
  ['juegos_5fp_40',['juegos_p',['../class_jugador.html#a33d916de7854955ca16f42e6fc6985d0',1,'Jugador::juegos_p()'],['../struct_torneo_1_1_actualizar__datos.html#a2a8987469d8b9cb8b4f824a475beb823',1,'Torneo::Actualizar_datos::juegos_p()']]],
  ['jugador_41',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a8f8147a78da8e2875870221a2c4ace0c',1,'Jugador::Jugador(int posicio)']]],
  ['jugador_2ecc_42',['Jugador.cc',['../_jugador_8cc.html',1,'']]],
  ['jugador_2ehh_43',['Jugador.hh',['../_jugador_8hh.html',1,'']]],
  ['jugadores_44',['jugadores',['../class_cjt___jugadores.html#ac2b56326b3d11412b9aa4baac7cd4bff',1,'Cjt_Jugadores']]]
];
