var searchData=
[
  ['actualizar_5fdatos_0',['Actualizar_datos',['../struct_torneo_1_1_actualizar__datos.html',1,'Torneo']]],
  ['actualizar_5fy_5flistar_1',['actualizar_y_listar',['../class_torneo.html#a53a8f0324d215f7e6a5a74f02be6b027',1,'Torneo']]]
];
