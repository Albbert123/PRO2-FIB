var searchData=
[
  ['ranking_5flocal_185',['ranking_local',['../class_torneo.html#a8aaa1273a91ab7a882a37f2e2ff96e67',1,'Torneo']]],
  ['resultados_186',['resultados',['../class_torneo.html#adb0ae255d28e1df379cb0484a5cdaf4f',1,'Torneo']]]
];
