var searchData=
[
  ['iniciar_5ftorneo_37',['iniciar_torneo',['../class_cjt___torneos.html#ae4d19a5b2730ed5ae86e2b0cdd134e98',1,'Cjt_Torneos::iniciar_torneo()'],['../class_torneo.html#a577aa6ee32e24b21346bc8c052b3cdb2',1,'Torneo::iniciar_torneo()']]],
  ['it_5franking_38',['it_ranking',['../class_cjt___jugadores.html#a9cf0d63f612892cb392545f3dcee19db',1,'Cjt_Jugadores']]]
];
