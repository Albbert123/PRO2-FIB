var searchData=
[
  ['juegos_5fg_170',['juegos_g',['../class_jugador.html#a12d726742e3690a515ae3def2c73b278',1,'Jugador::juegos_g()'],['../struct_torneo_1_1_actualizar__datos.html#a815ee965a3481284e3c0e858345fb030',1,'Torneo::Actualizar_datos::juegos_g()']]],
  ['juegos_5fp_171',['juegos_p',['../class_jugador.html#a33d916de7854955ca16f42e6fc6985d0',1,'Jugador::juegos_p()'],['../struct_torneo_1_1_actualizar__datos.html#a2a8987469d8b9cb8b4f824a475beb823',1,'Torneo::Actualizar_datos::juegos_p()']]],
  ['jugadores_172',['jugadores',['../class_cjt___jugadores.html#ac2b56326b3d11412b9aa4baac7cd4bff',1,'Cjt_Jugadores']]]
];
