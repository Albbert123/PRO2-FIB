var searchData=
[
  ['quitar_5fpuntos_74',['quitar_puntos',['../class_cjt___jugadores.html#a3eb9a298da6f0100e0f9d9789cdcf73b',1,'Cjt_Jugadores::quitar_puntos()'],['../class_torneo.html#a0f140336892193674dec79ecdc7b577f',1,'Torneo::quitar_puntos()']]],
  ['quitar_5fpuntuaciones_5fpasadas_75',['quitar_puntuaciones_pasadas',['../class_torneo.html#a5a91c8643326a6b07872be08c67e1c0f',1,'Torneo']]]
];
