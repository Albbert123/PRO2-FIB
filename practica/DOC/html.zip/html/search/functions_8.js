var searchData=
[
  ['main_145',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['max_5fcategoria_146',['max_categoria',['../class_cjt___categorias.html#a57d85e1050de74426cc8a7966dc8b584',1,'Cjt_Categorias']]],
  ['modificador_5ftorneo_147',['modificador_torneo',['../class_torneo.html#a99f49924a856cd89eb827a04b68ed881',1,'Torneo']]],
  ['modificar_5festadisticas_148',['modificar_estadisticas',['../class_cjt___jugadores.html#a125536f599e5a8e5280fd116ebfe5c9b',1,'Cjt_Jugadores']]],
  ['modificar_5fposicion_149',['modificar_posicion',['../class_cjt___jugadores.html#a2c707f96f23ef9b8a37b5e8ca547b1e3',1,'Cjt_Jugadores::modificar_posicion()'],['../class_jugador.html#a18cad0c7f6e4cc5b2e424794bd0b1293',1,'Jugador::modificar_posicion()']]]
];
