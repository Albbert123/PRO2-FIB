var searchData=
[
  ['actualizar_5fy_5flistar_110',['actualizar_y_listar',['../class_torneo.html#a53a8f0324d215f7e6a5a74f02be6b027',1,'Torneo']]]
];
