var searchData=
[
  ['it_5franking_169',['it_ranking',['../class_cjt___jugadores.html#a9cf0d63f612892cb392545f3dcee19db',1,'Cjt_Jugadores']]]
];
