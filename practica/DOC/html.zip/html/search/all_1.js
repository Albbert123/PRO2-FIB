var searchData=
[
  ['baja_5fjugador_2',['baja_jugador',['../class_cjt___jugadores.html#a9d22b96e26c2cea9c99bf2a86910c63b',1,'Cjt_Jugadores::baja_jugador()'],['../class_cjt___torneos.html#af94d77ff55c461906b6c44f925c64d80',1,'Cjt_Torneos::baja_jugador()'],['../class_torneo.html#a812206847995ad1d7a1bdfec29a6a82a',1,'Torneo::baja_jugador()']]],
  ['baja_5ftorneo_3',['baja_torneo',['../class_cjt___torneos.html#a60525c31279e61e3e50acd270a1cbee9',1,'Cjt_Torneos']]]
];
