var searchData=
[
  ['torneo_164',['Torneo',['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#aac74f4f1cb5c3f1ab05a9c9ade4b2e8b',1,'Torneo::Torneo(int categoria)']]]
];
