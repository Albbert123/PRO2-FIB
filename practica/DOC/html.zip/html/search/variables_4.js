var searchData=
[
  ['matpuntos_173',['matpuntos',['../class_cjt___categorias.html#ac3d86516094d6ed2578185ab3b44f862',1,'Cjt_Categorias']]]
];
