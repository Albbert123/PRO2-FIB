var searchData=
[
  ['emparejamiento_168',['emparejamiento',['../class_torneo.html#a63b4cf774b16334fc2de52d1cc0a6940',1,'Torneo']]]
];
