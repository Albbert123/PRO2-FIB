var searchData=
[
  ['ranking_5flocal_76',['ranking_local',['../class_torneo.html#a8aaa1273a91ab7a882a37f2e2ff96e67',1,'Torneo']]],
  ['reordenar_5franking_77',['reordenar_ranking',['../class_cjt___jugadores.html#abb4bc3b2d6bad22e62a853b2d4fe9a84',1,'Cjt_Jugadores']]],
  ['resultados_78',['resultados',['../class_torneo.html#adb0ae255d28e1df379cb0484a5cdaf4f',1,'Torneo']]]
];
