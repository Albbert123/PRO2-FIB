var searchData=
[
  ['jugador_97',['Jugador',['../class_jugador.html',1,'']]]
];
