var searchData=
[
  ['sets_5fg_79',['sets_g',['../class_jugador.html#a33bc41dbe108a2943bd251539607cd3a',1,'Jugador::sets_g()'],['../struct_torneo_1_1_actualizar__datos.html#a6072c7d56ca39699e56bc3cc0569ce0f',1,'Torneo::Actualizar_datos::sets_g()']]],
  ['sets_5fp_80',['sets_p',['../class_jugador.html#a2f51ea236aec0f33f5656b1914cf5b85',1,'Jugador::sets_p()'],['../struct_torneo_1_1_actualizar__datos.html#a0087685474745dbf25c03cce3bf7099d',1,'Torneo::Actualizar_datos::sets_p()']]],
  ['sumar_5fjuegos_5fg_81',['sumar_juegos_g',['../class_jugador.html#af7a0582013d8a582f727fe619c1114ce',1,'Jugador']]],
  ['sumar_5fjuegos_5fp_82',['sumar_juegos_p',['../class_jugador.html#a71b510c46ab93da7e73948fdb86f282d',1,'Jugador']]],
  ['sumar_5fpartidos_5fg_83',['sumar_partidos_g',['../class_jugador.html#ad2bc4ee32dd7bfae4477ddaa8a50ee00',1,'Jugador']]],
  ['sumar_5fpartidos_5fp_84',['sumar_partidos_p',['../class_jugador.html#a3c2b47726ffd2d38653bca389bc18a78',1,'Jugador']]],
  ['sumar_5fpuntos_85',['sumar_puntos',['../class_jugador.html#a22133b2d0adba42c83101123e3812e2e',1,'Jugador']]],
  ['sumar_5fsets_5fg_86',['sumar_sets_g',['../class_jugador.html#ae470fb7277f8d76233518c9a087e54bb',1,'Jugador']]],
  ['sumar_5fsets_5fp_87',['sumar_sets_p',['../class_jugador.html#af9ac1cff8ded8183f5f949d781c020bc',1,'Jugador']]],
  ['sumar_5ftorneos_88',['sumar_torneos',['../class_jugador.html#ab7512550d5aa06a3a6284ab223e08da5',1,'Jugador']]]
];
