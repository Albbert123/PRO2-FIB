var searchData=
[
  ['ncategorias_58',['ncategorias',['../class_cjt___categorias.html#aeec2cb24ed37ebf0be8cd7eef7c251d3',1,'Cjt_Categorias']]],
  ['ninscritos_59',['ninscritos',['../class_torneo.html#ae6f20d0a2f649597b382a2fe12f111ee',1,'Torneo']]],
  ['njugadores_60',['njugadores',['../class_cjt___jugadores.html#a0bb6bef86c8f7ee081c39ed31adfe91c',1,'Cjt_Jugadores']]],
  ['nniveles_61',['nniveles',['../class_cjt___categorias.html#abb1deaba421b91ddcba9744c5dc03ba3',1,'Cjt_Categorias']]],
  ['ntorneos_62',['ntorneos',['../class_cjt___torneos.html#abe78b1117380fd45467d8aa4334cf0b9',1,'Cjt_Torneos']]],
  ['nuevo_5fjugador_63',['nuevo_jugador',['../class_cjt___jugadores.html#a7cfa474e5d6b7f070cd86b60c7c67c69',1,'Cjt_Jugadores']]],
  ['nuevo_5ftorneo_64',['nuevo_torneo',['../class_cjt___torneos.html#affbd282cb668e6db57e0c70f7cdb2dc8',1,'Cjt_Torneos']]]
];
