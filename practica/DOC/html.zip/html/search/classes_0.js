var searchData=
[
  ['actualizar_5fdatos_93',['Actualizar_datos',['../struct_torneo_1_1_actualizar__datos.html',1,'Torneo']]]
];
