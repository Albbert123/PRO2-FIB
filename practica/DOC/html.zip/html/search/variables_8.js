var searchData=
[
  ['sets_5fg_187',['sets_g',['../class_jugador.html#a33bc41dbe108a2943bd251539607cd3a',1,'Jugador::sets_g()'],['../struct_torneo_1_1_actualizar__datos.html#a6072c7d56ca39699e56bc3cc0569ce0f',1,'Torneo::Actualizar_datos::sets_g()']]],
  ['sets_5fp_188',['sets_p',['../class_jugador.html#a2f51ea236aec0f33f5656b1914cf5b85',1,'Jugador::sets_p()'],['../struct_torneo_1_1_actualizar__datos.html#a0087685474745dbf25c03cce3bf7099d',1,'Torneo::Actualizar_datos::sets_p()']]]
];
