var searchData=
[
  ['ncategorias_174',['ncategorias',['../class_cjt___categorias.html#aeec2cb24ed37ebf0be8cd7eef7c251d3',1,'Cjt_Categorias']]],
  ['ninscritos_175',['ninscritos',['../class_torneo.html#ae6f20d0a2f649597b382a2fe12f111ee',1,'Torneo']]],
  ['njugadores_176',['njugadores',['../class_cjt___jugadores.html#a0bb6bef86c8f7ee081c39ed31adfe91c',1,'Cjt_Jugadores']]],
  ['nniveles_177',['nniveles',['../class_cjt___categorias.html#abb1deaba421b91ddcba9744c5dc03ba3',1,'Cjt_Categorias']]],
  ['ntorneos_178',['ntorneos',['../class_cjt___torneos.html#abe78b1117380fd45467d8aa4334cf0b9',1,'Cjt_Torneos']]]
];
