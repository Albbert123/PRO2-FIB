var searchData=
[
  ['jugador_137',['Jugador',['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a8f8147a78da8e2875870221a2c4ace0c',1,'Jugador::Jugador(int posicio)']]]
];
