var searchData=
[
  ['partido_152',['partido',['../class_torneo.html#a50d152634480a2d8152cd8743aed7753',1,'Torneo']]]
];
