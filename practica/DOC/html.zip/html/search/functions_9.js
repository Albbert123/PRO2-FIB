var searchData=
[
  ['nuevo_5fjugador_150',['nuevo_jugador',['../class_cjt___jugadores.html#a7cfa474e5d6b7f070cd86b60c7c67c69',1,'Cjt_Jugadores']]],
  ['nuevo_5ftorneo_151',['nuevo_torneo',['../class_cjt___torneos.html#affbd282cb668e6db57e0c70f7cdb2dc8',1,'Cjt_Torneos']]]
];
