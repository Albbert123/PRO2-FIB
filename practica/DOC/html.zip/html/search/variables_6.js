var searchData=
[
  ['partidos_5fg_179',['partidos_g',['../class_jugador.html#a564b17540c41d559f294c5daf2956f0a',1,'Jugador::partidos_g()'],['../struct_torneo_1_1_actualizar__datos.html#a55f2ef921d9eb9275e747d3d4a0bbb8c',1,'Torneo::Actualizar_datos::partidos_g()']]],
  ['partidos_5fp_180',['partidos_p',['../class_jugador.html#ac19c3b9a88d68f5a264e121927a981ca',1,'Jugador::partidos_p()'],['../struct_torneo_1_1_actualizar__datos.html#a700c4f8881c329091cc84a3c5f148cb9',1,'Torneo::Actualizar_datos::partidos_p()']]],
  ['posicion_181',['posicion',['../class_jugador.html#a0c0f3be497388acec0e2c890dcd46850',1,'Jugador']]],
  ['primer_5ftorneo_182',['primer_torneo',['../class_torneo.html#af34e43f0cc62c47a866f2b13941a6dbc',1,'Torneo']]],
  ['puntos_183',['puntos',['../class_jugador.html#a4e264d857d5a3f1a68cbb13e4b88930f',1,'Jugador::puntos()'],['../struct_torneo_1_1_actualizar__datos.html#a547a316a22376a7ca494b48f852b461b',1,'Torneo::Actualizar_datos::puntos()']]],
  ['puntuaciones_5fpasadas_184',['puntuaciones_pasadas',['../class_torneo.html#a2de6557b7c8a64f94c318c15af168083',1,'Torneo']]]
];
