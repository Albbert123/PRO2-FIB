var searchData=
[
  ['reordenar_5franking_155',['reordenar_ranking',['../class_cjt___jugadores.html#abb4bc3b2d6bad22e62a853b2d4fe9a84',1,'Cjt_Jugadores']]]
];
